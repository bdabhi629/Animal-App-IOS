
import SwiftUI

@main
struct AfricaApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
